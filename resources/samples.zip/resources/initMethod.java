implements InitAction {

public void init() {
	new WebAppServletSynchro();		
}

