@Override
public void create() throws CadseException {
	super.create();
 
	String packageName = getPackageNameAttribute(getItem());
	String className   = getClassNameAttribute(getItem());
 
	// Create servlet Java file           
	String servletContent = new ServletGenerator().generate(packageName, className);
	
	try {
		Path targetPath = new Path("sources/" + packageName.replaceAll("\\.","/"));
		MappingManager.generate(this.getProject(),
			targetPath,
			className + ".java",
			servletContent,
			EclipseTool.getDefaultMonitor());
		} catch (CoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}
 
