import model.webapp.template.ServletGenerator;
import org.eclipse.core.runtime.Path;
import fede.workspace.tool.eclipse.MappingManager;
import fede.workspace.tool.eclipse.EclipseTool;
import org.eclipse.core.runtime.CoreException;
