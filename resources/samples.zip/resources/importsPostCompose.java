import org.eclipse.core.resources.IProject;
import java.util.ArrayList;
import model.webapp.template.ServletJO;
import model.webapp.template.WebXMLGenerator;
import fede.workspace.tool.eclipse.MappingManager;
import fede.workspace.tool.eclipse.EclipseTool;
import org.eclipse.core.runtime.CoreException;
import model.webapp.template.WarFileUtil;

