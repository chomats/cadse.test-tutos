	@Override
	protected void postCompose(IBuildingContext context, List listExportedContent) {
		super.postCompose(context, listExportedContent);
		// Retrieve project reference
		ProjectContentManager contentMgr = (ProjectContentManager) getContentItem();
		IProject project = contentMgr.getProject();
		// Retrieve servlet informations
		List servletList = new ArrayList();
		for (Item item : getHasComp(getItem())) {
			// We are only interrested in Servlet items
			if (!item.isInstanceOf(WebAppModelCST.SERVLET))
				continue;
			servletList.add(new ServletJO(
					ServletManager.getPackageNameAttribute(item),
					ServletManager.getClassNameAttribute(item),
					ServletManager.getRelativeURLAttribute(item)));
		}
		// Generate web.xml file content
		String content = new WebXMLGenerator().generate(servletList);
		// Generate web.xml file
		try {
			MappingManager.generate(project,
					new Path("WEB-INF"),
					"web.xml",
					content,
					EclipseTool.getDefaultMonitor());
		} catch (CoreException e) {
			return; // ignore exceptions
		}

		// create dist folder
		try {
			MappingManager.createFolder(project.getFolder("dist"),
					EclipseTool.getDefaultMonitor());
		} catch (CoreException e) {
			return; // ignore exceptions
		}

		// Generate the war file
		WarFileUtil.createWarFile(project, getItem().getUniqueName());
	}

