package model.webapp;

import fr.imag.adele.cadse.core.CadseException;
import fr.imag.adele.cadse.core.Item;
import fr.imag.adele.cadse.core.transaction.delta.ItemDelta;
import fr.imag.adele.cadse.core.transaction.AbstractLogicalWorkspaceTransactionListener;
import fr.imag.adele.cadse.core.transaction.LogicalWorkspaceTransaction;




public class WebAppServletSynchro extends AbstractLogicalWorkspaceTransactionListener {

	public WebAppServletSynchro() {
		WebAppModelCST.SERVLET.addLogicalWorkspaceTransactionListener(this);
	}
	
	@Override
	public void notifyCreatedItem(LogicalWorkspaceTransaction wc, ItemDelta item)
	throws CadseException {

		// Create ServletAPI library if not exists
		Item servletApiItem = wc.createItemIfNeed(
				null,
				"ServletAPI",
				WebAppModelCST.LIBRARY,
				null,
				null);


		// Add a uses link between this Servlet item and the ServletAPI library item
		wc.createLinkIfNeed(item,
				servletApiItem,
				WebAppModelCST.WEB_COMPONENT_lt_USES);
	}
}


